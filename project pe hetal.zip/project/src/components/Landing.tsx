import React from 'react';
import { Wand2, Zap, Brain, Palette } from 'lucide-react';

interface LandingProps {
  onGetStarted: () => void;
}

function Landing({ onGetStarted }: LandingProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-16">
        <div className="inline-block animate-float">
          <Wand2 className="h-16 w-16 text-fuchsia-600 mb-6" />
        </div>
        <h1 className="text-6xl font-bold mb-6">
          Craft Perfect
          <span className="bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text"> Social Posts</span>
        </h1>
        <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
          Transform your ideas into engaging content with our AI-powered post generator. Create stunning visuals and captivating captions in seconds.
        </p>
        <button
          onClick={onGetStarted}
          className="bg-gradient-to-r from-fuchsia-600 to-violet-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:opacity-90 transition-all transform hover:scale-105 shadow-xl flex items-center mx-auto group"
        >
          <Wand2 className="mr-2 h-5 w-5 group-hover:rotate-12 transition-transform" />
          Start Crafting
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-all">
          <div className="bg-gradient-to-br from-fuchsia-100 to-violet-100 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <Zap className="h-7 w-7 text-fuchsia-600" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800">Instant Magic</h3>
          <p className="text-gray-600">Transform your ideas into engaging posts within seconds using our advanced AI technology</p>
        </div>
        <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-all">
          <div className="bg-gradient-to-br from-violet-100 to-purple-100 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <Brain className="h-7 w-7 text-violet-600" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800">AI-Powered Creativity</h3>
          <p className="text-gray-600">Let our intelligent algorithms craft the perfect captions and visuals for your content</p>
        </div>
        <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-all">
          <div className="bg-gradient-to-br from-purple-100 to-cyan-100 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
            <Palette className="h-7 w-7 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800">Perfect Style</h3>
          <p className="text-gray-600">Generate content that matches your unique brand voice and aesthetic preferences</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl overflow-hidden transform hover:scale-[1.02] transition-all">
          <img
            src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&q=80"
            alt="Content Creation Workspace"
            className="w-full h-80 object-cover"
          />
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl overflow-hidden transform hover:scale-[1.02] transition-all">
          <img
            src="https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&q=80"
            alt="Social Media Content"
            className="w-full h-80 object-cover"
          />
        </div>
      </div>
    </div>
  );
}

export default Landing;