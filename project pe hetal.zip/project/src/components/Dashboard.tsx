import React, { useState } from 'react';
import { PenTool, Copy, CheckCircle, RefreshCw, Image as ImageIcon } from 'lucide-react';

interface GeneratedContent {
  post: string;
  imageUrl: string;
  captions: string[];
}

const SAMPLE_IMAGES = {
  nature: [
    'https://images.unsplash.com/photo-1469474968028-56623f02e42e',
    'https://images.unsplash.com/photo-1426604966848-d7adac402bff',
    'https://images.unsplash.com/photo-1472214103451-9374bd1c798e',
  ],
  food: [
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836',
    'https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445',
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38',
  ],
  technology: [
    'https://images.unsplash.com/photo-1518770660439-4636190af475',
    'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
    'https://images.unsplash.com/photo-1451187580459-43490279c0fa',
  ],
  travel: [
    'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee',
    'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1',
    'https://images.unsplash.com/photo-1503220317375-aaad61436b1b',
  ],
  fitness: [
    'https://images.unsplash.com/photo-1517836357463-d25dfeac3438',
    'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b',
    'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61',
  ]
};

const HASHTAG_TEMPLATES = {
  nature: ['Nature', 'NatureLover', 'Outdoors', 'NaturePhotography', 'EarthFocus'],
  food: ['FoodLover', 'Foodie', 'FoodPhotography', 'Yummy', 'InstantFood'],
  technology: ['Tech', 'Innovation', 'Future', 'TechLife', 'Digital'],
  travel: ['Travel', 'Wanderlust', 'Adventure', 'Explore', 'TravelPhotography'],
  fitness: ['Fitness', 'HealthyLifestyle', 'Workout', 'FitnessMotivation', 'FitLife']
};

function Dashboard() {
  const [prompt, setPrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const getRandomImage = (keyword: string): string => {
    const category = Object.keys(SAMPLE_IMAGES).find(key => 
      keyword.toLowerCase().includes(key)
    ) || 'nature';
    
    const images = SAMPLE_IMAGES[category as keyof typeof SAMPLE_IMAGES];
    const randomIndex = Math.floor(Math.random() * images.length);
    return `${images[randomIndex]}?auto=format&fit=crop&q=80`;
  };

  const getHashtags = (keyword: string): string[] => {
    const category = Object.keys(HASHTAG_TEMPLATES).find(key => 
      keyword.toLowerCase().includes(key)
    ) || 'nature';
    
    return HASHTAG_TEMPLATES[category as keyof typeof HASHTAG_TEMPLATES];
  };

  const generateCaption = (topic: string): string => {
    const emojis = ['✨', '🌟', '💫', '🎯', '🚀', '💪', '🌈', '🎨'];
    const randomEmoji = () => emojis[Math.floor(Math.random() * emojis.length)];
    
    const hashtags = getHashtags(topic)
      .map(tag => `#${tag}`)
      .join(' ');

    return `${randomEmoji()} Exploring the amazing world of ${topic}! ${randomEmoji()}\n\nEvery moment with ${topic} creates unforgettable experiences and inspiring stories. Let's embark on this journey together!\n\n${hashtags}`;
  };

  const handleGenerate = () => {
    setIsGenerating(true);
    
    // Simulate API delay
    setTimeout(() => {
      const imageUrl = getRandomImage(prompt);
      const mainCaption = generateCaption(prompt);
      
      const alternativeCaptions = [
        `✨ Discovering the magic of ${prompt}`,
        `🌟 When ${prompt} meets inspiration`,
        `💫 Creating moments with ${prompt}`,
        `🎯 Embracing the beauty of ${prompt}`
      ];

      setGeneratedContent({
        post: mainCaption,
        imageUrl,
        captions: alternativeCaptions
      });
      
      setIsGenerating(false);
    }, 1500);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text">
          Create Your Content
        </h2>
        <div className="mb-6">
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">
            What's on your mind?
          </label>
          <textarea
            id="prompt"
            rows={4}
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-fuchsia-500 focus:border-fuchsia-500 transition-all"
            placeholder="Try topics like: nature, food, technology, travel, fitness..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
        </div>
        <button
          onClick={handleGenerate}
          disabled={!prompt || isGenerating}
          className={`w-full bg-gradient-to-r from-fuchsia-600 to-violet-600 text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-all flex items-center justify-center ${
            (!prompt || isGenerating) && 'opacity-50 cursor-not-allowed'
          }`}
        >
          {isGenerating ? (
            <>
              <RefreshCw className="animate-spin h-5 w-5 mr-2" />
              Crafting your content...
            </>
          ) : (
            <>
              <PenTool className="h-5 w-5 mr-2" />
              Generate Content
            </>
          )}
        </button>
      </div>

      {generatedContent && (
        <div className="space-y-8">
          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text">
                Your Image
              </h3>
            </div>
            <div className="rounded-xl overflow-hidden">
              <img 
                src={generatedContent.imageUrl} 
                alt={prompt}
                className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text">
                Your Caption
              </h3>
              <button
                onClick={() => handleCopy(generatedContent.post)}
                className="flex items-center text-gray-600 hover:text-fuchsia-600 transition-colors"
              >
                {isCopied ? (
                  <>
                    <CheckCircle className="h-5 w-5 mr-1" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-5 w-5 mr-1" />
                    Copy
                  </>
                )}
              </button>
            </div>
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="whitespace-pre-wrap text-gray-700">{generatedContent.post}</p>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text">
                Alternative Captions
              </h3>
            </div>
            <div className="space-y-3">
              {generatedContent.captions.map((caption, index) => (
                <div key={index} className="flex justify-between items-center bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                  <p className="text-gray-700">{caption}</p>
                  <button
                    onClick={() => handleCopy(caption)}
                    className="ml-4 text-gray-600 hover:text-fuchsia-600 transition-colors"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;