import React, { useState } from 'react';
import { Wand2, Layout, Home, PenTool } from 'lucide-react';
import Landing from './components/Landing';
import Dashboard from './components/Dashboard';

function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'dashboard'>('landing');
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-fuchsia-100 via-violet-200 to-cyan-100">
      <nav className="bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Wand2 className="h-8 w-8 text-fuchsia-600" />
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-fuchsia-600 to-violet-600 text-transparent bg-clip-text">
                PostCrafter
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setCurrentPage('landing')}
                className={`flex items-center px-3 py-2 rounded-md ${
                  currentPage === 'landing'
                    ? 'bg-fuchsia-100 text-fuchsia-700'
                    : 'text-gray-600 hover:bg-fuchsia-50'
                }`}
              >
                <Home className="h-5 w-5 mr-1" />
                Home
              </button>
              <button
                onClick={() => setCurrentPage('dashboard')}
                className={`flex items-center px-3 py-2 rounded-md ${
                  currentPage === 'dashboard'
                    ? 'bg-fuchsia-100 text-fuchsia-700'
                    : 'text-gray-600 hover:bg-fuchsia-50'
                }`}
              >
                <Layout className="h-5 w-5 mr-1" />
                Create
              </button>
            </div>
          </div>
        </div>
      </nav>

      {currentPage === 'landing' ? <Landing onGetStarted={() => setCurrentPage('dashboard')} /> : <Dashboard />}
    </div>
  );
}

export default App;